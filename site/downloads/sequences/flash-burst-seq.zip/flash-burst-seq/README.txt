ZYNQ FX — Flash Burst Sequence (24 frames, 640x360, RGBA)
Import as image sequence in After Effects / Premiere / Resolve / Final Cut.
Blend mode: Screen / Add.
